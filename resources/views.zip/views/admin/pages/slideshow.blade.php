@extends('admin.dash')
@section('content')
<div class="container">
	<!-- <div class="row"> -->
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<form method="POST" action="{{url('/')}}/admin/slideshow" class="dropzone" id="addSlideshow" enctype="multipart/form-data">
				{{ csrf_field() }}
			</form>
		</div>
		<button class="btn btn-info btn-sm waves-effect waves-light" onclick="location.reload();">Show</button>
<!-- 	</div>
	<div class="row"> -->
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<table class="table table-bordered table-condensed table-hover">
				<thead>
					<tr>
						<th class="text-center blue white-text">Delete</th>
						<th class="text-center blue white-text">Edit</th>
						<th class="text-center blue white-text">Order</th>
						<th class="text-center blue white-text">Images</th>
						<th class="text-center blue white-text">Title</th>
						<th class="text-center blue white-text">Short Desc</th>
						<th class="text-center blue white-text">Link</th>
						
					</tr>
				</thead>
				<tbody>
				@foreach ($slideshows as $slideshow)
					<tr>
						<td>
							<form method="post" action="{{url('/')}}/admin/slideshow/{{ $slideshow->id }}" class="delete_form_slideshow">
								{{ csrf_field() }}
								<input type="hidden" name="_method" value="DELETE">
								<button id="delete-slideshow-btn">
								<i class="material-icons red-text">delete_forever</i>
								</button>
							</form>
						</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
				@endforeach
				</tbody>
			</table>
		</div>
	<!-- </div> -->
</div>
@endsection
@section('footer')
<script type="application/javascript" src="{{ asset('src/public/js/libs/dropzone.js') }}"></script>
<script>
	Dropzone.options.addSlideshow = {
		paramName: 'photo',
		maxFilesize: 2,
		maxFiles: 12,
		acceptedFiles: '.jpg, .jpeg, .png'
	}
</script>
@endsection