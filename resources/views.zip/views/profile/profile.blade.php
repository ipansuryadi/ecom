@extends('app')

@section('content')

    <div id="wrapper">

        @include('pages.partials.side-nav')

        <!-- Button to toggle side-nav -->
        <a href="#menu-toggle" class="btn btn-default visible-xs" id="menu-toggle"><i class="fa fa-bars fa-5x"></i></a>

        <div class="container-fluid">

            <div class="col-md-6">

                <h4 class="text-center">Your Profile</h4><br>
                <a href="{{ url('profile/add') }}" class="btn btn-primary">Add new Address</a>
                <div class="menu">
                    <div class="accordion">
                        @if (count($address) == 0)
                            You have no address
                        @else
                            @foreach($address as $addr)
                                <div class="accordion-group">
                                    <div class="accordion-heading" id="accordion-group">
                                    <form action="{{url('profile/delete')}}" method="post" class="delete_form_address" accept-charset="utf-8">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="address_id" value="{{$addr->id}}"></input>
                                        <a class="accordion-toggle" data-toggle="collapse" href="#addr{{$addr->id}}">{{$addr->name}} - {{$addr->kecamatan}}</a> 
                                        <button class="pull-right" id="delete-address-btn">
                                    </form>
                            <i class="material-icons red-text">delete_forever</i>
                        </button>
                                    </div>
                                    <div id="addr{{$addr->id}}" class="accordion-body collapse">
                                        <div class="accordion-inner">
                                            <table class="table table-striped table-condensed">
                                                <tbody>
                                                    <tr><th>Name</th><td>{{$addr->name}}</td></tr>
                                                    <tr><th>Email</th><td>{{$addr->email}}</td></tr>
                                                    <tr><th>Phone</th><td>{{$addr->phone}}</td></tr>
                                                    <tr><th>Provinsi</th><td>{{$addr->provinsi}}</td></tr>
                                                    <tr><th>Kabupaten / Kota</th><td>{{$addr->kabupaten}}</td></tr>
                                                    <tr><th>Kecamatan</th><td>{{$addr->kecamatan}}</td></tr>
                                                    <tr><th>Address</th><td>{{$addr->address}}</td></tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        @endif
                    </div>
                </div>

            </div>

        </div>  <!-- close container-fluid -->

    </div>  <!-- close wrapper -->


@endsection