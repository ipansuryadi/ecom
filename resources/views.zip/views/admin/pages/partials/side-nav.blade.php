

<div id="wrapper">

    <!-- Sidebar -->
    <div id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <!-- <li>
                <a href="{{ url('admin/dashboard') }}">Dashboard</a>
            </li> -->
            <li>
                <a href="{{ url('admin/categories') }}">Categories</a>
            </li>
            <li>
                <a href="{{ url('admin/brands') }}">Brands</a>
            </li>
            <li>
                <a href="{{ url('admin/products') }}">Products</a>
            </li>
            <li>
                <a href="{{ url('admin/order') }}">Order</a>
            </li>
            <li>
                <a href="{{ url('admin/user') }}">User</a>
            </li>
            <li>
                <a href="{{ url('admin/slideshow') }}">Slideshow</a>
            </li>
            <li>
                <a href="">Shipping Cost</a>
            </li>
            <li>
                <a href="">Bank Account</a>
            </li>
        </ul>
    </div>
