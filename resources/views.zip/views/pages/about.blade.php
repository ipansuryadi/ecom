@extends('app')

@section('content')

<div id="wrapper">

    @include('pages.partials.side-nav')
    
    

    <!-- Button to toggle side-nav -->
    <a href="#menu-toggle" class="btn btn-default visible-xs" id="menu-toggle"><i class="fa fa-bars fa-5x"></i></a>

    @include('pages.partials.about')

    @include('pages.partials.footer')

    </div>  <!-- close wrapper -->

@stop
