@extends('app')
@section('content')

<div id="wrapper">
    @include('pages.partials.side-nav')
    <!-- Button to toggle side-nav -->
    <a href="#menu-toggle" class="btn btn-default visible-xs" id="menu-toggle"><i class="fa fa-bars fa-5x"></i></a>
    <div class="container-fluid">
        <div class="col-md-12">
            <a href="#" onclick="window.history.back();return false;" class="btn btn-danger">Back</a>
            <div class="row">
                <form action="{{url('profile/post')}}" method="POST" role="form">
                {{ csrf_field() }}
                    <legend class="text-center">Add New Address</legend>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                        
                        <div class="form-group">
                            <label for="">Name</label>
                            <input type="text" name="name" class="form-control" id="" placeholder="Input field">
                        </div>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="email" name="email" class="form-control" id="" placeholder="Input field">
                        </div>
                        <div class="form-group">
                            <label for="">Phone</label>
                            <input type="text" name="phone" class="form-control" id="" placeholder="Input field">
                        </div>
                        <div class="form-group">
                            <label for="">Address</label>
                            <textarea name="address" id="input" class="form-control" rows="3" required="required"></textarea>
                        </div>
                        
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                        <div class="form-group">
                            <label for="">Provinsi</label>
                            <select name="provinsi"  id="loadProv" class="form-control" required="required">
                                <option value="" selected="" disabled="">Provinsi</option>

                                @foreach ($provinsi as $element)
                                {{-- expr --}}
                                <option value="{{$element->id}}">{{$element->provinsi_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Kabupaten/Kota</label>
                            <select name="kabupaten" id="loadKab" class="form-control" required="required">
                                <option value="" selected="" disabled="">Kabupaten / Kota</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Kecamatan</label>
                            <select name="kecamatan" id="loadKec" class="form-control" required="required">
                                <option value="" selected="" disabled="">Kecamatan</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary pull-right">Submit</button>
                    </div>
                </form>
            </div>
        </div>
        </div>  <!-- close container-fluid -->
        </div>  <!-- close wrapper -->
        @endsection