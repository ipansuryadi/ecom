@extends('app')
@section('content')
<div id="wrapper">
    @include('pages.partials.side-nav')
    <!-- Button to toggle side-nav -->
    <a href="#menu-toggle" class="btn btn-default visible-xs" id="menu-toggle"><i class="fa fa-bars fa-5x"></i></a>
    <div class="container-fluid">
        <div class="col-md-12">
            <h4 class="text-center">Your Orders</h4><br>
            <div class="menu">
                <div class="accordion">
                    @if ($orders->count() == 0)
                    You have no orders
                    @else
                    @foreach($orders as $order)
                    <div class="accordion-group">
                        <div class="accordion-heading" id="accordion-group">
                            <a class="accordion-toggle" data-toggle="collapse" href="#order{{$order->id}}">Order #{{$order->id}} - {{prettyDate($order->created_at)}} - Status : {{strtoupper($order->status)}}</a>
                        </div>
                        <div id="order{{$order->id}}" class="accordion-body collapse">
                            <div class="accordion-inner">
                                <table class="table table-striped table-condensed">
                                    <thead>
                                        <tr>
                                            <th>
                                                Product
                                            </th>
                                            <th>
                                                Quantity
                                            </th>
                                            <th>
                                                Product Price
                                            </th>
                                            <th>
                                                Total
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($order->orderItems as $orderitem)
                                        <tr>
                                            <td><a href="{{ route('show.product', $orderitem->product_name) }}">{{$orderitem->product_name}}</a></td>
                                            <td>{{$orderitem->pivot->qty}}</td>
                                            <td>
                                                @if($orderitem->pivot->reduced_price == 0)
                                                {{ xformatMoney($orderitem->pivot->price) }}
                                                @else
                                                {{ xformatMoney($orderitem->pivot->reduced_price) }}
                                                @endif
                                            </td>
                                            <td>
                                                @if ($orderitem->pivot->total_reduced == 0)
                                                {{xformatMoney($orderitem->pivot->total)}}
                                                @else
                                                {{xformatMoney($orderitem->pivot->total_reduced)}}
                                                @endif
                                            </td>
                                        </tr>
                                        @endforeach
                                        <tr>
                                            <td><b>Shipping Cost</b></td>
                                            <td></td>
                                            <td></td>
                                            <td>{{$order->total_ongkir}}</td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td><b>Total</b></td>
                                            <td><b>${{xformatMoney($order->total)}}</b></td>
                                        </tr>
                                        <tr>
                                            <td colspan="4">
                                                <div class="col-sm-12 col-md-6">
                                                    <table class="table">
                                                        <caption><b>Shipping Address</b></caption>
                                                        <tbody>
                                                            <tr><td>To </td><td>: {{ $order->address['name'] }}</td></tr>
                                                            <tr><td>Email </td><td>: {{ $order->address['email'] }}</td></tr>
                                                            <tr><td>Phone </td><td>: {{ $order->address['phone'] }}</td></tr>
                                                            <tr><td>Address </td><td>: {{ $order->address['address'] }}</td></tr>
                                                            <tr><td></td><td>: {{ $order->address['provinsi'] }} / {{ $order->address['kabupaten'] }} / {{ $order->address['kecamatan'] }}</td></tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="col-sm-12 col-md-6">
                                                    <table class="table">
                                                        <caption><b>Shipping Detail</b></caption>
                                                        <tbody>
                                                            <tr><td>Courier </td><td>: {{ $order->kurir }}</td></tr>
                                                            <tr><td>Tracking Number </td><td>: {{ $order->no_resi }}</td></tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                
                                            </td>
                                        </tr>
                                        @if ($order->status == "unpaid")
                                        <tr><td colspan="4"><a href="{{ url('order/confirmation') }}/{{$order->id}}" class="btn btn-primary pull-right" title="">Payment Confirmation</a></td></tr>
                                        @endif
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    @endforeach
                    @endif
                </div>
            </div>
        </div>
        </div>  <!-- close container-fluid -->
        </div>  <!-- close wrapper -->
        @endsection