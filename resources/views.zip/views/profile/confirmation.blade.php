@extends('app')
@section('content')
<div id="wrapper">
    @include('pages.partials.side-nav')
    <!-- Button to toggle side-nav -->
    <a href="#menu-toggle" class="btn btn-default visible-xs" id="menu-toggle"><i class="fa fa-bars fa-5x"></i></a>
    <div class="container-fluid">
        <div class="col-md-12">
            <h4 class="text-center">Confirm Payment</h4>
            <div class="col-sm-12 col-md-8 col-md-offset-2">
                @foreach($orders as $order)
                <div class="panel panel-default">
                    <div class="panel-heading warning-color white-text">Order No : {{$order->id}} - {{prettyDate($order->created_at)}}</div>
                    <div class="panel-body">
                        <table class="table table-striped table-condensed">
                            <thead>
                                <tr>
                                    <th>
                                        Product
                                    </th>
                                    <th>
                                        Quantity
                                    </th>
                                    <th>
                                        Product Price
                                    </th>
                                    <th>
                                        Total
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($order->orderItems as $orderitem)
                                <tr>
                                    <td><a href="{{ route('show.product', $orderitem->product_name) }}">{{$orderitem->product_name}}</a></td>
                                    <td>{{$orderitem->pivot->qty}}</td>
                                    <td>
                                        @if($orderitem->pivot->reduced_price == 0)
                                        {{ xformatMoney($orderitem->pivot->price) }}
                                        @else
                                        {{ xformatMoney($orderitem->pivot->reduced_price) }}
                                        @endif
                                    </td>
                                    <td>
                                        @if ($orderitem->pivot->total_reduced == 0)
                                        {{xformatMoney($orderitem->pivot->total)}}
                                        @else
                                        {{xformatMoney($orderitem->pivot->total_reduced)}}
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                                <tr>
                                    <td colspan="3">Shipping Cost</td>
                                    <td>{{$order->total_ongkir}}</td>
                                </tr>
                            </tbody>
                            <tfoot>
                            <tr><th colspan="3">Total</th><th>{{$order->total}}</th></tr>
                            </tfoot>
                        </table>
                        <div class="panel panel-default">
                            <div class="panel-heading">Shipping information</div>
                            <div class="panel-body">
                                <div class="col-md-3">Name:</div><div class="col-md-9"> {{$order->address->name}}</div>
                                <div class="col-md-3">Email:</div><div class="col-md-9"> {{$order->address->email}}</div>
                                <div class="col-md-3">Phone:</div><div class="col-md-9"> {{$order->address->phone}}</div>
                                <div class="col-md-3">Provinsi:</div><div class="col-md-9"> {{$order->address->provinsi}}</div>
                                <div class="col-md-3">Kabupaten / Kota:</div><div class="col-md-9"> {{$order->address->kabupaten}}</div>
                                <div class="col-md-3">Kecamatan:</div><div class="col-md-9"> {{$order->address->kecamatan}}</div>
                                <div class="col-md-3">Address:</div><div class="col-md-9"> {{$order->address->address}}</div>
                            </div>
                        </div>
                        <form action="{{ url('order/confirmation') }}" method="POST" role="form">
                        {{ csrf_field() }}
                        <input type="hidden" name="order_id" value="{{$order->id}}">
                            <legend>Form Confirmation</legend>
                            
                            <div class="form-group">
                                <label for="">Bank Name</label>
                                <input type="text" name="bank_name" class="form-control" id="" placeholder="Input field">
                            </div>
                            <div class="form-group">
                                <label for="">Bank Account Name</label>
                                <input type="text" name="account_name" class="form-control" id="" placeholder="Input field">
                            </div>
                            <div class="form-group">
                                <label for="">Bank Account Number</label>
                                <input type="text" name="account_no" class="form-control" id="" placeholder="Input field">
                            </div>
                            <div class="form-group">
                                <label for="">Select Bank</label>
                                <select name="bank_id" id="input" class="form-control" required="required">
                                    @foreach ($banks as $element)
                                        <option value="{{$element->id}}">{{$element->bank_name}}, {{$element->account_name}}, {{$element->account_no}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Amount</label>
                                <input type="text" name="amount" class="form-control" id="" placeholder="Input field">
                            </div>
                            <button type="submit" class="btn btn-primary pull-right">Submit</button>
                        </form>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
        </div>  <!-- close container-fluid -->
        </div>  <!-- close wrapper -->
        @endsection