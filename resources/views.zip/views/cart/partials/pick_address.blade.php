@if ($cart_total === 0)

@else
    @if (count($address) == 0)
        <a href="{{ url('profile') }}" class="list-group-item list-group-item-danger">You dont have any address. Please make new address from profile menu.</a>
    @else
        {{-- false expr --}}
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default" id="Checkout-Shipping-Payment-Container">
                    <div class="panel-heading">Select Shipping information</div>
                    <div class="panel-body">
                        <form id="payment-form" role="form" method="POST" action="{{url('/')}}/order">
                            {!! csrf_field() !!}
                            <table class="table table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Select</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Email</th>
                                        <th>Full Address</th>
                                        <th>Cost</th>
                                    </tr>
                                </thead>
                                <tbody>
                                @foreach ($address as $addr)
                                    {{-- expr --}}
                                    <tr>
                                        <td><input type="radio" name="address_id" value="{{$addr->id}}|{{$weight_total*$addr->tarif}}"></td>
                                        <td>{{$addr->name}}</td>
                                        <td>{{$addr->phone}}</td>
                                        <td>{{$addr->email}}</td>
                                        <td>{{$addr->address}}</td>
                                        <td><b>{{$weight_total*$addr->tarif}}</b></td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            <div class="col-md-12">
                                <br><br>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-default waves-effect waves-light pull-right">
                                        CONFIRM
                                    </button>
                                </div>
                            </div>
                        </form> <!-- close form -->

                    </div>  <!-- close panel-body -->
                </div>  <!-- close panel-default -->
            </div>  <!-- close col-md-10 -->
        </div>  <!-- row -->
    @endif
@endif

<br><br><br><br> <br><br><br><br>