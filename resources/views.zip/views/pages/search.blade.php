@extends('app')
@section('content')
<div id="wrapper">
    @include('pages.partials.side-nav')
    <!-- Button to toggle side-nav -->
    <a href="#menu-toggle" class="btn btn-default visible-xs" id="menu-toggle"><i class="fa fa-bars fa-5x"></i></a>
    <div class="container-fluid">
        <h6>
        Search results for: <i>{{ $query }}</i>
        </h6><br>
        @if (count($search) === 0)
        No products found
        @elseif (count($search) >= 1)
        @foreach($search as $product)
        <!-- <div class="col-sm-6 col-md-3 wow zoomIn" id="product-sub-container"> -->
        <div class="col-sm-6 col-md-3 wow zoomIn" id="featured-products-sub-container">
            <a href="{{ route('show.product', $product->product_name) }}">
                @if ($product->photos->count() === 0)
                <img src="{{url('/')}}/src/public/images/no-image-found.jpg" alt="No Image Found Tag" id="Product-similar-Image" style="width: 200px; height: 200px;">
                @else
                @if ($product->featuredPhoto)
                <img src="{{url('/')}}/{{ $product->featuredPhoto->thumbnail_path }}" alt="Photo ID: {{ $product->featuredPhoto->id }}" />
                @elseif(!$product->featuredPhoto)
                <img src="{{url('/')}}/{{ $product->photos->first()->thumbnail_path}}" alt="Photo" />
                @else
                N/A
                @endif
                @endif
                <div id="featured-product-name-container">
                    <h6 class="center-on-small-only" id="featured-product-name"><br>{{ $product->product_name }}</h6>
                </div>
                @if($product->reduced_price == 0)
                <div class="light-300 black-text medium-500" id="Product_Reduced-Price">{{  xformatMoney($product->price) }}</div>
                @else
                <div class="green-text medium-500" id="Product_Reduced-Price">{{ xformatMoney($product->reduced_price) }}</div>
                @endif
            </a>
            <form action="{{url('/')}}/cart/add" method="post" name="add_to_cart">
                {!! csrf_field() !!}
                <input type="hidden" name="product" value="{{$product->id}}" />
                <input type="hidden" name="weight" value="{{$product->weight}}" />
                <input type="hidden" name="qty" value="1" />
                <button class="btn btn-default waves-effect waves-light">ADD TO CART</button>
            </form>
        </div>
        
        @endforeach
        @endif
        </div>      <!-- Close container-fluid -->
        </div>  <!-- Close wrapper -->
        @endsection